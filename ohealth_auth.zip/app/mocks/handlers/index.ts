// app/mocks/handlers/index.ts
import { appointmentHandlers } from "./appointments";
import { profileSetupHandlers } from "./profile-setup";
import { authHandlers } from "./auth";

export const handlers = [
  ...appointmentHandlers,
  ...profileSetupHandlers,
  ...authHandlers,
];
