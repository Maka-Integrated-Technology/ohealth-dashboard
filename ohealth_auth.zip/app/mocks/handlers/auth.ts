// app/mocks/handlers/auth.ts
import { delay, http, HttpResponse } from "msw";
import type { LoginPayload, VerifyEmailPayload } from "~/features/auth/types";

const MOCK_NETWORK_DELAY_MS = 500;

// TODO(remove-when-live): temporary mocks for the login flow while the
// backend /auth/login and /auth/login/verify endpoints aren't available on
// staging yet. Delete this file and its entry in handlers/index.ts once
// they're confirmed live — do not leave this wired up in production.
export const authHandlers = [
  http.post("*/api/v1/auth/login", async ({ request }) => {
    await delay(MOCK_NETWORK_DELAY_MS);
    const body = (await request.json()) as LoginPayload;
    return HttpResponse.json({ email: body.email });
  }),

  http.post("*/api/v1/auth/login/verify", async ({ request }) => {
    await delay(MOCK_NETWORK_DELAY_MS);
    const body = (await request.json()) as VerifyEmailPayload;

    if (body.code !== "123456") {
      return HttpResponse.json(
        { message: "Code is not valid" },
        { status: 400 }
      );
    }

    return HttpResponse.json({
      accessToken: "mock-access-token",
      refreshToken: "mock-refresh-token",
    });
  }),
];
